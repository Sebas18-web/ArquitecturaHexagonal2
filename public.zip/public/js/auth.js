const API_URL = 'http://localhost:8080/api';

// Mostrar mensajes
function showMessage(message, type = 'error') {
    const messageDiv = document.getElementById('message');
    if (messageDiv) {
        messageDiv.textContent = message;
        messageDiv.className = `message ${type}`;
        messageDiv.style.display = 'block';
        
        if (type === 'success') {
            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 3000);
        }
    }
}

// Guardar información del usuario
function saveUserData(userData) {
    localStorage.setItem('authToken', userData.token);
    localStorage.setItem('userName', userData.user.name);
    localStorage.setItem('userEmail', userData.user.email);
    console.log('🔐 Datos de usuario guardados');
}

// Registrar usuario
if (document.getElementById('registerForm')) {
    document.getElementById('registerForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            password: document.getElementById('password').value
        };

        console.log('📝 Registrando usuario:', formData.email);

        try {
            const response = await fetch(`${API_URL}/users`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (data.success) {
                showMessage('✅ Cuenta creada! Redirigiendo...', 'success');
                setTimeout(() => {
                    window.location.href = '/login.html';
                }, 1500);
            } else {
                showMessage(data.error || 'Error al crear la cuenta');
            }
        } catch (error) {
            console.error('❌ Error en registro:', error);
            showMessage('Error de conexión. Verifica que UserService esté ejecutándose.');
        }
    });
}

// Iniciar sesión
if (document.getElementById('loginForm')) {
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = {
            email: document.getElementById('email').value,
            password: document.getElementById('password').value
        };

        console.log('🔐 Login:', formData.email);

        try {
            const response = await fetch(`${API_URL}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (data.success) {
                showMessage('✅ Login exitoso! Redirigiendo...', 'success');
                saveUserData(data.data);
                setTimeout(() => {
                    window.location.href = '/dashboard.html';
                }, 1500);
            } else {
                showMessage(data.error || 'Credenciales incorrectas');
            }
        } catch (error) {
            console.error('❌ Error en login:', error);
            showMessage('Error de conexión. Verifica que UserService esté ejecutándose.');
        }
    });
}

// Verificar autenticación
function checkAuth() {
    const token = localStorage.getItem('authToken');
    const currentPage = window.location.pathname;
    
    if (token && (currentPage === '/login.html' || currentPage === '/register.html' || currentPage === '/')) {
        window.location.href = '/dashboard.html';
    }
    
    if (!token && currentPage === '/dashboard.html') {
        window.location.href = '/login.html';
    }
}

document.addEventListener('DOMContentLoaded', checkAuth);
