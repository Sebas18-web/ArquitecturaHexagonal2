const USER_SERVICE_URL = 'http://localhost:8080';
const ADMIN_SERVICE_URL = 'http://localhost:9090';

// Cargar información del usuario
function loadUserInfo() {
    const token = localStorage.getItem('authToken');
    
    if (!token) {
        window.location.href = '/login.html';
        return;
    }

    // Por ahora, usar datos mock - en una app real harías una llamada a la API
    document.getElementById('userName').textContent = 'Maria Garcia';
    document.getElementById('userEmail').textContent = 'maria@test.com';
}

// Mostrar mensajes en el dashboard
function showDashboardMessage(message, type = 'error') {
    const messageDiv = document.getElementById('message');
    if (messageDiv) {
        messageDiv.textContent = message;
        messageDiv.className = `message ${type}`;
        messageDiv.style.display = 'block';
        
        if (type === 'success') {
            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 3000);
        }
    }
}

// Enviar mensaje
async function sendMessage(messageData) {
    const token = localStorage.getItem('authToken');
    
    try {
        showDashboardMessage('📤 Enviando mensaje...', 'success');
        
        // Simular envío (en una app real harías fetch a la API)
        setTimeout(() => {
            showDashboardMessage('✅ Mensaje enviado correctamente!', 'success');
            addMessageToHistory({
                content: messageData.content,
                queue: messageData.queue,
                timestamp: new Date().toISOString(),
                status: 'processed'
            });
        }, 1000);

    } catch (error) {
        console.error('❌ Error enviando mensaje:', error);
        showDashboardMessage(`Error: ${error.message}`);
    }
}

// Agregar mensaje al historial
function addMessageToHistory(message) {
    const historyList = document.getElementById('historyList');
    const messageElement = document.createElement('div');
    messageElement.className = 'message-item';
    messageElement.innerHTML = `
        <div class="message-meta">
            <span>${new Date(message.timestamp).toLocaleString()}</span>
            <span>Queue: ${message.queue}</span>
            <span>Status: ${message.status}</span>
        </div>
        <div class="message-content">
            ${message.content}
        </div>
    `;
    historyList.prepend(messageElement);
}

// Cargar historial de mensajes (simulado)
function loadMessageHistory() {
    const historyList = document.getElementById('historyList');
    
    // Mensajes de ejemplo
    const sampleMessages = [
        {
            content: '¡Bienvenido al sistema de mensajes!',
            queue: 'hello',
            timestamp: new Date().toISOString(),
            status: 'processed'
        },
        {
            content: 'Este es un mensaje de prueba',
            queue: 'hello', 
            timestamp: new Date(Date.now() - 300000).toISOString(),
            status: 'processed'
        }
    ];

    if (sampleMessages.length === 0) {
        historyList.innerHTML = `
            <p style="text-align: center; color: #666; padding: 20px;">
                No hay mensajes en el historial
            </p>
        `;
        return;
    }

    historyList.innerHTML = sampleMessages.map(message => `
        <div class="message-item">
            <div class="message-meta">
                <span>${new Date(message.timestamp).toLocaleString()}</span>
                <span>Queue: ${message.queue}</span>
                <span>Status: ${message.status}</span>
            </div>
            <div class="message-content">
                ${message.content}
            </div>
        </div>
    `).join('');
}

// Cerrar sesión
function logout() {
    console.log('🚪 Cerrando sesión...');
    localStorage.removeItem('authToken');
    localStorage.removeItem('userName');
    localStorage.removeItem('userEmail');
    window.location.href = '/login.html';
}

// Inicializar dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticación
    const token = localStorage.getItem('authToken');
    if (!token) {
        window.location.href = '/login.html';
        return;
    }

    // Cargar datos del usuario
    loadUserInfo();
    
    // Cargar historial de mensajes
    loadMessageHistory();

    // Configurar envío de mensajes
    const messageForm = document.getElementById('messageForm');
    if (messageForm) {
        messageForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const content = document.getElementById('content').value;
            const queue = document.getElementById('queue').value;
            
            if (!content.trim()) {
                showDashboardMessage('Por favor, escribe un mensaje');
                return;
            }

            try {
                const messageData = {
                    content: content.trim(),
                    queue: queue
                };

                await sendMessage(messageData);
                
                // Limpiar formulario
                document.getElementById('content').value = '';
                
            } catch (error) {
                // El error ya se muestra en sendMessage
            }
        });
    }

    console.log('✅ Dashboard inicializado correctamente');
    console.log('🔗 UserService:', USER_SERVICE_URL);
    console.log('🔗 AdminService:', ADMIN_SERVICE_URL);
});
