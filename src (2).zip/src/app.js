require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 9090;

// ✅ ALMACENAMIENTO EN MEMORIA
let activityLogs = [];

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// ✅ API ADMINISTRATIVA - OBTENER LOGS
app.get('/api/admin/activity-logs', async (req, res) => {
  try {
    const { userId, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let filteredLogs = activityLogs;
    if (userId) {
      filteredLogs = activityLogs.filter(log => log.userId === userId);
    }

    // Ordenar por timestamp descendente
    filteredLogs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    // Paginación
    const paginatedLogs = filteredLogs.slice(offset, offset + parseInt(limit));

    res.json({
      success: true,
      data: {
        logs: paginatedLogs,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(filteredLogs.length / limit),
          totalLogs: filteredLogs.length
        }
      }
    });

  } catch (error) {
    console.error('Error obteniendo logs:', error);
    res.status(500).json({
      success: false,
      error: 'Error interno del servidor'
    });
  }
});

// ✅ SIMULAR RECEPCIÓN DE EVENTOS
app.post('/api/admin/simulate-event', (req, res) => {
  try {
    const { userId, action, description } = req.body;

    const newLog = {
      id: uuidv4(),
      userId,
      action,
      description,
      timestamp: new Date().toISOString()
    };

    activityLogs.push(newLog);

    console.log('📨 Evento simulado recibido:', action);

    res.json({
      success: true,
      message: 'Evento procesado',
      data: newLog
    });

  } catch (error) {
    console.error('Error simulando evento:', error);
    res.status(500).json({
      success: false,
      error: 'Error interno del servidor'
    });
  }
});

// ✅ HEALTH CHECK
app.get('/health', (req, res) => {
  res.json({
    success: true,
    service: 'AdminService',
    port: PORT,
    status: 'OK',
    architecture: 'Hexagonal',
    logsCount: activityLogs.length,
    timestamp: new Date().toISOString()
  });
});

// ✅ INICIALIZACIÓN
app.listen(PORT, () => {
  console.log('\n✨ ========================================');
  console.log('🚀 AdminService (Hexagonal) ejecutándose!');
  console.log(`📍 Puerto: ${PORT}`);
  console.log(`🌍 URL: http://localhost:${PORT}`);
  console.log(`📊 Logs: http://localhost:${PORT}/api/admin/activity-logs`);
  console.log(`❤️ Health: http://localhost:${PORT}/health`);
  console.log(`🏗️ Arquitectura: Hexagonal`);
  console.log('========================================\n');
});
