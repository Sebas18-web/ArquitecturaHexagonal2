class UserCreatedEventHandler {
  constructor(activityLogRepository) {
    this.activityLogRepository = activityLogRepository;
  }

  async handle(event) {
    console.log('📨 AdminService: Procesando evento USER_CREATED');

    // Crear log de actividad
    const ActivityLog = require('../../domain/entities/ActivityLog');
    const activityLog = new ActivityLog(
      null,
      event.data.userId,
      'USER_REGISTRATION',
      `Nuevo usuario registrado: ${event.data.name} (${event.data.email})`
    );

    // Guardar en base de datos
    await this.activityLogRepository.save(activityLog);

    // Simular otras acciones administrativas
    await this.sendInternalNotification(event.data);
    await this.updateMetrics();

    console.log('✅ AdminService: Evento procesado correctamente');
  }

  async sendInternalNotification(userData) {
    console.log(`📢 Notificación interna: Nuevo usuario ${userData.name}`);
    // Aquí podrías enviar email, notificación, etc.
  }

  async updateMetrics() {
    console.log('📊 Actualizando métricas de usuarios');
    // Aquí podrías actualizar dashboards, métricas, etc.
  }
}

module.exports = UserCreatedEventHandler;