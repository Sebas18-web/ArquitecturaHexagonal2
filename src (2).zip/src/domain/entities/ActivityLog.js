const { v4: uuidv4 } = require('uuid');

class ActivityLog {
  constructor(id, userId, action, description, timestamp = new Date()) {
    this.id = id || uuidv4();
    this.userId = userId;
    this.action = action;
    this.description = description;
    this.timestamp = timestamp;
    this.validate();
  }

  validate() {
    if (!this.userId) {
      throw new Error('UserId es requerido');
    }
    if (!this.action || this.action.trim().length === 0) {
      throw new Error('Action es requerido');
    }
    if (!this.description || this.description.trim().length === 0) {
      throw new Error('Description es requerido');
    }
  }

  toJSON() {
    return {
      id: this.id,
      userId: this.userId,
      action: this.action,
      description: this.description,
      timestamp: this.timestamp
    };
  }
}

module.exports = ActivityLog;