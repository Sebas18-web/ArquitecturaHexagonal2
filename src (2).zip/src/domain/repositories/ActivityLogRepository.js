class ActivityLogRepository {
  async save(activityLog) {
    throw new Error('Método no implementado');
  }

  async findByUserId(userId, page = 1, limit = 20) {
    throw new Error('Método no implementado');
  }

  async findAll(page = 1, limit = 20) {
    throw new Error('Método no implementado');
  }
}

module.exports = ActivityLogRepository;