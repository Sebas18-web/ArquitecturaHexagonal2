class AdminController {
  constructor(activityLogRepository) {
    this.activityLogRepository = activityLogRepository;
  }

  async getActivityLogs(req, res) {
    try {
      const { userId, page = 1, limit = 20 } = req.query;

      let result;
      if (userId) {
        result = await this.activityLogRepository.findByUserId(userId, parseInt(page), parseInt(limit));
      } else {
        result = await this.activityLogRepository.findAll(parseInt(page), parseInt(limit));
      }

      res.json({
        success: true,
        data: result
      });

    } catch (error) {
      console.error('Error obteniendo logs:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor'
      });
    }
  }

  async getStats(req, res) {
    try {
      // Aquí podrías agregar estadísticas del sistema
      res.json({
        success: true,
        data: {
          service: 'AdminService',
          status: 'active',
          timestamp: new Date().toISOString(),
          features: [
            'Registro de logs de actividad',
            'Procesamiento de eventos',
            'Métricas del sistema'
          ]
        }
      });

    } catch (error) {
      console.error('Error obteniendo stats:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor'
      });
    }
  }
}

module.exports = AdminController;