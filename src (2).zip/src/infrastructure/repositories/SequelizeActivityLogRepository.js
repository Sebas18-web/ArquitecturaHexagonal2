const ActivityLogRepository = require('../../domain/repositories/ActivityLogRepository');
const ActivityLog = require('../../domain/entities/ActivityLog');
const { Sequelize } = require('sequelize');

class SequelizeActivityLogRepository extends ActivityLogRepository {
  constructor(sequelize) {
    super();
    this.sequelize = sequelize;
    this.initModel();
  }

  initModel() {
    this.ActivityLogModel = this.sequelize.define('ActivityLog', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      userId: {
        type: Sequelize.UUID,
        allowNull: false
      },
      action: {
        type: Sequelize.STRING,
        allowNull: false
      },
      description: {
        type: Sequelize.TEXT,
        allowNull: false
      },
      timestamp: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
      }
    }, {
      tableName: 'activity_logs',
      timestamps: false
    });
  }

  async save(activityLog) {
    await this.ActivityLogModel.create({
      id: activityLog.id,
      userId: activityLog.userId,
      action: activityLog.action,
      description: activityLog.description,
      timestamp: activityLog.timestamp
    });
  }

  async findByUserId(userId, page = 1, limit = 20) {
    const offset = (page - 1) * limit;
    
    const { count, rows } = await this.ActivityLogModel.findAndCountAll({
      where: { userId },
      order: [['timestamp', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    const logs = rows.map(row => 
      new ActivityLog(
        row.id,
        row.userId,
        row.action,
        row.description,
        row.timestamp
      )
    );

    return {
      logs,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(count / limit),
        totalLogs: count
      }
    };
  }

  async findAll(page = 1, limit = 20) {
    const offset = (page - 1) * limit;
    
    const { count, rows } = await this.ActivityLogModel.findAndCountAll({
      order: [['timestamp', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    const logs = rows.map(row => 
      new ActivityLog(
        row.id,
        row.userId,
        row.action,
        row.description,
        row.timestamp
      )
    );

    return {
      logs,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(count / limit),
        totalLogs: count
      }
    };
  }
}

module.exports = SequelizeActivityLogRepository;