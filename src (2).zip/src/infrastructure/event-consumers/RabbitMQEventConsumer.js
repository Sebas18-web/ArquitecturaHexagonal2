const amqp = require('amqplib');

class RabbitMQEventConsumer {
  constructor(connectionUrl, eventHandlers = {}) {
    this.connectionUrl = connectionUrl;
    this.eventHandlers = eventHandlers;
    this.connection = null;
    this.channel = null;
    this.isConsuming = false;
  }

  async connect() {
    try {
      this.connection = await amqp.connect(this.connectionUrl);
      this.channel = await this.connection.createChannel();
      await this.channel.assertQueue('user_events', { durable: true });
      console.log('✅ AdminService conectado a RabbitMQ');
    } catch (error) {
      console.error('❌ Error conectando AdminService a RabbitMQ:', error.message);
      throw error;
    }
  }

  async startConsuming() {
    if (this.isConsuming) {
      console.log('⚠️ El consumidor ya está activo');
      return;
    }

    if (!this.channel) {
      await this.connect();
    }

    console.log('🔄 AdminService iniciando consumo de eventos...');

    this.channel.consume('user_events', async (msg) => {
      if (msg !== null) {
        try {
          const event = JSON.parse(msg.content.toString());
          console.log(`📨 Evento recibido: ${event.type}`);

          // Ejecutar el manejador correspondiente
          const handler = this.eventHandlers[event.type];
          if (handler) {
            await handler.handle(event);
          } else {
            console.warn(`⚠️ No hay manejador para el evento: ${event.type}`);
          }

          this.channel.ack(msg);
        } catch (error) {
          console.error('❌ Error procesando evento:', error);
          this.channel.nack(msg, false, false); // Rechazar mensaje
        }
      }
    }, {
      noAck: false
    });

    this.isConsuming = true;
    console.log('✅ AdminService consumiendo eventos de RabbitMQ');
  }

  async stopConsuming() {
    if (this.channel) {
      await this.channel.close();
    }
    if (this.connection) {
      await this.connection.close();
    }
    this.isConsuming = false;
    console.log('🛑 AdminService detenido');
  }
}

module.exports = RabbitMQEventConsumer;