class UserRepository {
  async findById(id) {
    throw new Error('Método no implementado');
  }

  async findByEmail(email) {
    throw new Error('Método no implementado');
  }

  async save(user) {
    throw new Error('Método no implementado');
  }
}

module.exports = UserRepository;