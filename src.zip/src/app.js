require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { Sequelize } = require('sequelize');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 8080;

// ✅ CONFIGURACIÓN SQLITE - SIN INSTALACIÓN
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, 'user_service.db'),
  logging: console.log
});

// Modelo de Usuario
const User = sequelize.define('User', {
  id: {
    type: Sequelize.UUID,
    defaultValue: Sequelize.UUIDV4,
    primaryKey: true
  },
  name: {
    type: Sequelize.STRING,
    allowNull: false
  },
  email: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: Sequelize.STRING,
    allowNull: false
  },
  isActive: {
    type: Sequelize.BOOLEAN,
    defaultValue: true
  }
}, {
  tableName: 'users',
  timestamps: true,
  createdAt: 'createdAt',
  updatedAt: false
});

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Servir archivos estáticos del frontend
app.use(express.static(path.join(__dirname, '../../public')));

// ✅ REGISTRAR USUARIO
app.post('/api/users', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    console.log('📝 Intentando registrar usuario:', email);

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Nombre, email y contraseña son requeridos'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'La contraseña debe tener al menos 6 caracteres'
      });
    }

    // Verificar si el usuario ya existe
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: 'Ya existe un usuario con este email'
      });
    }

    // Hashear password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Crear usuario
    const user = await User.create({
      name,
      email,
      password: hashedPassword
    });

    console.log('✅ Usuario registrado exitosamente:', email);

    res.status(201).json({
      success: true,
      message: 'Usuario registrado exitosamente',
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          createdAt: user.createdAt
        }
      }
    });

  } catch (error) {
    console.error('❌ Error en registro:', error);
    res.status(500).json({
      success: false,
      error: 'Error interno del servidor'
    });
  }
});

// ✅ LOGIN DE USUARIO
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    console.log('🔐 Intentando login:', email);

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email y contraseña son requeridos'
      });
    }

    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Credenciales inválidas'
      });
    }

    // Verificar password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        error: 'Credenciales inválidas'
      });
    }

    // Generar token
    const token = jwt.sign(
      { userId: user.id },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '24h' }
    );

    console.log('✅ Login exitoso:', email);

    res.json({
      success: true,
      message: 'Login exitoso',
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email
        },
        token
      }
    });

  } catch (error) {
    console.error('❌ Error en login:', error);
    res.status(500).json({
      success: false,
      error: 'Error interno del servidor'
    });
  }
});

// ✅ OBTENER PERFIL DE USUARIO (Protegido)
app.get('/api/auth/profile', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Token requerido'
      });
    }

    // Verificar token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    const user = await User.findByPk(decoded.userId, {
      attributes: { exclude: ['password'] }
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'Usuario no encontrado'
      });
    }

    res.json({
      success: true,
      data: user
    });

  } catch (error) {
    console.error('❌ Error en perfil:', error);
    res.status(401).json({
      success: false,
      error: 'Token inválido'
    });
  }
});

// ✅ HEALTH CHECK
app.get('/health', (req, res) => {
  res.json({
    success: true,
    service: 'UserService',
    port: PORT,
    status: 'OK',
    database: 'SQLite',
    architecture: 'Hexagonal',
    timestamp: new Date().toISOString()
  });
});

// ✅ RUTAS DEL FRONTEND
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/login.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/login.html'));
});

app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/register.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/dashboard.html'));
});

// ✅ INICIALIZACIÓN
const startServer = async () => {
  try {
    await sequelize.authenticate();
    await sequelize.sync({ force: false });
    console.log('✅ SQLite UserService conectada y sincronizada');

    app.listen(PORT, () => {
      console.log('\n✨ ========================================');
      console.log('🚀 UserService (Hexagonal) ejecutándose!');
      console.log(`📍 Puerto: ${PORT}`);
      console.log(`🌍 URL: http://localhost:${PORT}`);
      console.log(`🔐 Login: http://localhost:${PORT}/login`);
      console.log(`📝 Register: http://localhost:${PORT}/register`);
      console.log(`💬 Dashboard: http://localhost:${PORT}/dashboard`);
      console.log(`❤️ Health: http://localhost:${PORT}/health`);
      console.log(`🗄️ Base de datos: SQLite`);
      console.log(`🏗️ Arquitectura: Hexagonal`);
      console.log('========================================\n');
    });

  } catch (error) {
    console.error('❌ Error iniciando UserService:', error);
    process.exit(1);
  }
};

// Manejo de cierre graceful
process.on('SIGINT', () => {
  console.log('\n🛑 Cerrando UserService...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Cerrando UserService...');
  process.exit(0);
});

startServer();