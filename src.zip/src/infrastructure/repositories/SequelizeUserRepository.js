const UserRepository = require('../../domain/repositories/UserRepository');
const User = require('../../domain/entities/User');
const { Sequelize } = require('sequelize');

class SequelizeUserRepository extends UserRepository {
  constructor(sequelize) {
    super();
    this.sequelize = sequelize;
    this.initModel();
  }

  initModel() {
    this.UserModel = this.sequelize.define('User', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      email: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
      },
      password: {
        type: Sequelize.STRING,
        allowNull: false
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        defaultValue: true
      }
    }, {
      tableName: 'users',
      timestamps: true,
      createdAt: 'createdAt',
      updatedAt: false
    });
  }

  async findById(id) {
    const userData = await this.UserModel.findByPk(id);
    if (!userData) return null;
    
    return new User(
      userData.id,
      userData.name,
      userData.email,
      userData.password,
      userData.isActive,
      userData.createdAt
    );
  }

  async findByEmail(email) {
    const userData = await this.UserModel.findOne({ where: { email } });
    if (!userData) return null;
    
    return new User(
      userData.id,
      userData.name,
      userData.email,
      userData.password,
      userData.isActive,
      userData.createdAt
    );
  }

  async save(user) {
    await this.UserModel.upsert({
      id: user.id,
      name: user.name,
      email: user.email,
      password: user.password,
      isActive: user.isActive,
      createdAt: user.createdAt
    });
  }
}

module.exports = SequelizeUserRepository;
