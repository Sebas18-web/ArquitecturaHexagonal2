class UserController {
  constructor(createUserUseCase) {
    this.createUserUseCase = createUserUseCase;
  }

  async register(req, res) {
    try {
      const { name, email, password } = req.body;

      const user = await this.createUserUseCase.execute({
        name,
        email,
        password
      });

      // Generar token
      const jwt = require('jsonwebtoken');
      const token = jwt.sign(
        { userId: user.id },
        process.env.JWT_SECRET || 'secret',
        { expiresIn: '24h' }
      );

      res.status(201).json({
        success: true,
        message: 'Usuario registrado exitosamente',
        data: {
          user: user.toJSON(),
          token
        }
      });

    } catch (error) {
      console.error('Error en registro:', error);
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }

  async login(req, res) {
    try {
      const { email, password } = req.body;

      const userRepository = req.userRepository;
      const user = await userRepository.findByEmail(email);

      if (!user || !(await user.comparePassword(password))) {
        return res.status(401).json({
          success: false,
          error: 'Credenciales inválidas'
        });
      }

      const jwt = require('jsonwebtoken');
      const token = jwt.sign(
        { userId: user.id },
        process.env.JWT_SECRET || 'secret',
        { expiresIn: '24h' }
      );

      res.json({
        success: true,
        message: 'Login exitoso',
        data: {
          user: user.toJSON(),
          token
        }
      });

    } catch (error) {
      console.error('Error en login:', error);
      res.status(500).json({
        success: false,
        error: 'Error interno del servidor'
      });
    }
  }
}

module.exports = UserController;