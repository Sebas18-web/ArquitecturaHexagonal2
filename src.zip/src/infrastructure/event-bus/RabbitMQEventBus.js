const amqp = require('amqplib');

class RabbitMQEventBus {
  constructor(connectionUrl) {
    this.connectionUrl = connectionUrl;
    this.connection = null;
    this.channel = null;
  }

  async connect() {
    try {
      this.connection = await amqp.connect(this.connectionUrl);
      this.channel = await this.connection.createChannel();
      await this.channel.assertQueue('user_events', { durable: true });
      console.log('✅ Conectado a RabbitMQ desde UserService');
    } catch (error) {
      console.error('❌ Error conectando a RabbitMQ:', error.message);
      throw error;
    }
  }

  async publish(event) {
    if (!this.channel) {
      await this.connect();
    }

    try {
      const message = Buffer.from(JSON.stringify(event));
      this.channel.sendToQueue('user_events', message, { persistent: true });
      console.log('📨 Evento publicado:', event.type);
    } catch (error) {
      console.error('❌ Error publicando evento:', error);
      throw error;
    }
  }
}

module.exports = RabbitMQEventBus;