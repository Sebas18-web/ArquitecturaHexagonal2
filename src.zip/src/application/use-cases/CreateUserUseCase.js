const User = require('../../domain/entities/User');

class CreateUserUseCase {
  constructor(userRepository, eventBus) {
    this.userRepository = userRepository;
    this.eventBus = eventBus;
  }

  async execute(userData) {
    // Verificar si el usuario ya existe
    const existingUser = await this.userRepository.findByEmail(userData.email);
    if (existingUser) {
      throw new Error('Ya existe un usuario con este email');
    }

    // Crear entidad de dominio
    const user = new User(
      null,
      userData.name,
      userData.email,
      userData.password
    );

    // Hashear password
    await user.hashPassword();

    // Guardar usuario
    await this.userRepository.save(user);

    // Publicar evento
    await this.eventBus.publish({
      type: 'USER_CREATED',
      data: {
        userId: user.id,
        name: user.name,
        email: user.email,
        createdAt: user.createdAt
      },
      timestamp: new Date().toISOString()
    });

    return user;
  }
}

module.exports = CreateUserUseCase;